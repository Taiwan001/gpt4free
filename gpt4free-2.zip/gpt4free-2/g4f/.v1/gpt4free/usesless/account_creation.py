import usesless

usesless.Account.create(logging=True)
